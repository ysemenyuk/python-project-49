import random


def getRandomInt(A=1, B=21):
    return random.randint(A, B)
