#!/usr/bin/env python3

from brain_games.games.brain_progression_game import brain_progression_game


def main():
    print('Welcome to the Brain Games!')
    brain_progression_game()


if __name__ == '__main__':
    main()
