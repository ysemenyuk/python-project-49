### Hexlet tests and linter status:
[![Actions Status](https://github.com/ysemenyuk/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ysemenyuk/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/fd606f77869321e04e64/maintainability)](https://codeclimate.com/github/ysemenyuk/python-project-49/maintainability)